package com.example.donationapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.wallet.PaymentsClient;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button payButton = findViewById(R.id.payButton);
        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText amountEditText = findViewById(R.id.amountEditText);

        // Pay button click listener
        payButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString();
            String amount = amountEditText.getText().toString();

            if (name.isEmpty() || amount.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter all details!", Toast.LENGTH_SHORT).show();
            } else {
                // Initiate UPI payment
                payUsingUPI(name, amount, "UPI ID");  // Replace with your actual UPI ID
            }
        });
    }

    // UPI payment initiation method
    private void payUsingUPI(String name, String amount, String upiId) {
        Uri uri = Uri.parse("upi://pay")
                .buildUpon()
                .appendQueryParameter("pa", upiId)  // UPI ID (your personal UPI ID)
                .appendQueryParameter("pn", name)   // Donor's name
                .appendQueryParameter("tn", "Donation Payment")  // Transaction note
                .appendQueryParameter("am", amount)  // Donation amount
                .appendQueryParameter("cu", "INR")  // Currency (INR)
                .build();

        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
        upiPayIntent.setData(uri);

        // Check if UPI app exists
        Intent chooser = Intent.createChooser(upiPayIntent, "Pay with");
        if (chooser.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(chooser, 1);
        } else {
            Toast.makeText(MainActivity.this, "No UPI app found. Please install one to continue.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the UPI payment result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {
            if (resultCode == RESULT_OK || resultCode == 11) {
                if (data != null) {
                    String response = data.getStringExtra("response");
                    if (response != null) {
                        String status = "";
                        String[] responseArray = response.split("&");
                        for (String res : responseArray) {
                            if (res.startsWith("Status")) {
                                status = res.split("=")[1];
                            }
                        }

                        if (status.equalsIgnoreCase("SUCCESS")) {
                            // Payment successful
                            Intent successIntent = new Intent(this, SuccessActivity.class);
                            startActivity(successIntent);
                        } else {
                            // Payment failed
                            Intent failureIntent = new Intent(this, FailureActivity.class);
                            startActivity(failureIntent);
                        }
                    }
                } else {
                    Toast.makeText(this, "Transaction canceled", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Transaction failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }
    }
